LaRedColect SEO files (free)
Upload robots.txt and sitemap.xml (NOT this README) to the repository root of:
https://github.com/arajanshaze-star/laredcolect-site/upload/main
Then click Commit changes.
These files help search engines discover the site but do not guarantee indexing or traffic.
